import csv
import json

def convert_dashboard_csv_to_json(csv_filepath, json_filepath):
    # 1. 初始化与大屏所需完全一致的 JSON 骨架
    data = {
        "stats": {},
        "salesTrend": {"x": [], "y": []},
        "categoryShare": [],
        "regionSales": {"x": [], "y": []},
        "trafficSource": {"indicator": [], "value": []},
        "userGrowth": {"x": [], "y": []},
        "taskRate": 0
    }

    # 2. 读取 CSV 文件
    with open(csv_filepath, mode='r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        
        # 尝试跳过表头 (如果第一行包含 'dataset' 关键字)
        header = next(reader, None)
        if header and 'dataset' not in header[0]:
            # 如果第一行不是表头而是数据，我们需要重置读取指针或把这行重新处理
            # 这里的简单做法是直接把这行当数据处理（为了稳妥起见）
            process_row(header, data)

        # 3. 逐行解析数据
        for row in reader:
            process_row(row, data)

    # 4. 写入 JSON 文件
    with open(json_filepath, mode='w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"✅ 转换成功！JSON 数据已保存至: {json_filepath}")

def process_row(row, data):
    """处理 CSV 单行数据的辅助函数"""
    # 忽略空行或列数不足的行
    if not row or len(row) < 3 or not row[0].strip():
        return

    dataset = row[0].strip()
    label = row[1].strip()
    
    try:
        value = float(row[2].strip())
    except ValueError:
        value = 0
        
    # 处理可能存在的 extra 列 (针对雷达图)
    extra = None
    if len(row) > 3 and row[3].strip():
        try:
            extra = float(row[3].strip())
        except ValueError:
            pass

    # 5. 根据 dataset 分发数据
    if dataset == 'stats':
        # 兼容处理销售额字段名
        key = 'monthSales' if label == 'monthSalesWan' else label
        data["stats"][key] = value
    elif dataset == 'salesTrend':
        data["salesTrend"]["x"].append(label)
        data["salesTrend"]["y"].append(value)
    elif dataset == 'categoryShare':
        data["categoryShare"].append({"name": label, "value": value})
    elif dataset == 'regionSales':
        data["regionSales"]["x"].append(label)
        data["regionSales"]["y"].append(value)
    elif dataset == 'trafficSource':
        data["trafficSource"]["indicator"].append({"name": label, "max": extra or 100})
        data["trafficSource"]["value"].append(value)
    elif dataset == 'userGrowth':
        data["userGrowth"]["x"].append(label)
        data["userGrowth"]["y"].append(value)
    elif dataset == 'taskRate':
        data["taskRate"] = value

# --- 运行示例 ---
if __name__ == "__main__":
    # 假设你的 CSV 文件名为 dashboard_data_v2.csv
    input_csv = "dashboard_data_v2.csv"
    output_json = "data_converted.json"
    
    convert_dashboard_csv_to_json(input_csv, output_json)